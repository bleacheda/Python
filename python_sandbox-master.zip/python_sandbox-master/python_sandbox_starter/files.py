# Python has functions for creating, reading, updating, and deleting files.
