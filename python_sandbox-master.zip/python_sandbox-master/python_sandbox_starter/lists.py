# A List is a collection which is ordered and changeable. Allows duplicate members.
